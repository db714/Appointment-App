# Appointment_App
-This is an appointment application for Software 2(C195). The application allows the user to add/modify/update Customers as well as add/modify/delete Appointments. The application also has 3 different reports that can be populated.

-David Brown(student id:001313638), dbro833@wgu.edu, student application version(1.0), 01/24/2022

(Build Information)
-IDE: IntelliJ Community(2021.1.3)
-Java SE JDK: version 16.0.2
-JavaFX API: version 17
-JavaFX: version 11.0.2

(Running Application)
-Upon startup use the default login: Username "Test", Password "Test"

(Extra Report)
-The 3rd report outputs the number of customers located in a selected country.

(MySQL connector)
-verison 8.0.26










